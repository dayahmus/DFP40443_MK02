<?php
$nama = "NURUL HIDAYAH BINTI MUSTAFA";
$nomatrik = "18DIT24F1994";
$kelas = "DIT4E";
?>

<!DOCTYPE html>
<html>
<head>
    <title>Maklumat Diri</title>
</head>
<body>
<center>
    <h1>Maklumat Pelajar</h1>

    <img src="gambar.png" width="200" alt="Gambar Diri">

    <p><strong>Nama:</strong> <?= $nama ?></p>
    <p><strong>No Matrik:</strong> <?= $nomatrik ?></p>
    <p><strong>Kelas:</strong> <?= $kelas ?></p>
</center>
</body>
</html>